
  # PayOS Fintech UI Design

  This is a code bundle for PayOS Fintech UI Design. The original project is available at https://www.figma.com/design/naBgj6yFnZAoyWgVPD8l0U/PayOS-Fintech-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  