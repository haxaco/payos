'use client';

import { AccountsPage } from '../../../pages/AccountsPage';

export default function Accounts() {
  return <AccountsPage />;
}