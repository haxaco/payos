'use client';

import { WebhooksPage } from '../../../pages/WebhooksPage';

export default function Webhooks() {
  return <WebhooksPage />;
}
