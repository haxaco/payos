'use client';

import { RequestLogsPage } from '../../../pages/RequestLogsPage';

export default function RequestLogs() {
  return <RequestLogsPage />;
}
