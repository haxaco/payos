'use client';

import { APIKeysPage } from '../../../pages/APIKeysPage';

export default function APIKeys() {
  return <APIKeysPage />;
}
