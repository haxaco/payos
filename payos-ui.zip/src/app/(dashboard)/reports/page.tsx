'use client';

import { ReportsPage } from '../../../pages/ReportsPage';

export default function Reports() {
  return <ReportsPage />;
}
