import { InputHTMLAttributes } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export function Input({ label, error, className = '', ...props }: InputProps) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label className="text-gray-700 dark:text-gray-300">
          {label}
        </label>
      )}
      <input
        className={`px-3 py-2 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-colors ${error ? 'border-error-500' : ''} ${className}`}
        {...props}
      />
      {error && (
        <span className="text-error-600 dark:text-error-400">{error}</span>
      )}
    </div>
  );
}
