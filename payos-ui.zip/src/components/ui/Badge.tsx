type BadgeVariant = 'success' | 'warning' | 'error' | 'info' | 'neutral';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
}

const variantStyles: Record<BadgeVariant, string> = {
  success: 'bg-green-100 dark:bg-green-950 text-green-700 dark:text-green-400',
  warning: 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400',
  error: 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-400',
  info: 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-400',
  neutral: 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300',
};

export function Badge({ children, variant = 'neutral', size = 'md' }: BadgeProps) {
  return (
    <span className={`
      inline-flex items-center font-semibold rounded-full
      ${size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'}
      ${variantStyles[variant]}
    `}>
      {children}
    </span>
  );
}
